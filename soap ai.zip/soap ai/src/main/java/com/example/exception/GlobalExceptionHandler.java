package com.example.exception;

import org.springframework.ws.soap.server.endpoint.annotation.FaultCode;
import org.springframework.ws.soap.server.endpoint.annotation.SoapFault;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ControllerAdvice
public class GlobalExceptionHandler {
    
    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @SoapFault(faultCode = FaultCode.SERVER)
    public void handleGenericException(Exception ex) {
        logger.error("An error occurred: ", ex);
        throw new RuntimeException("Internal Server Error");
    }

    @SoapFault(faultCode = FaultCode.CLIENT)
    public void handleUserNotFoundException(UserNotFoundException ex) {
        logger.warn("User not found: ", ex);
        throw ex;
    }
}