package com.example.endpoint;

import com.example.service.UserService;
import com.example.model.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.xpath;

@SpringBootTest
@AutoConfigureMockMvc
public class UserEndpointTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @Test
    public void getUserShouldReturnUser() throws Exception {
        // Arrange
        User mockUser = new User();
        mockUser.setId(1);
        mockUser.setName("Test User");
        mockUser.setEmail("test@example.com");
        
        when(userService.getUserById(anyInt())).thenReturn(mockUser);

        String request = 
            "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
            "xmlns:us=\"http://example.com/users\">" +
            "<soapenv:Body>" +
            "<us:getUserRequest><us:id>1</us:id></us:getUserRequest>" +
            "</soapenv:Body></soapenv:Envelope>";

        // Act & Assert
        mockMvc.perform(post("/ws")
                .contentType("text/xml")
                .content(request))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(xpath("//us:name").string("Test User"))
                .andExpect(xpath("//us:email").string("test@example.com"));
    }

    @Test
    public void getUserShouldHandleError() throws Exception {
        // Arrange
        when(userService.getUserById(anyInt())).thenThrow(new RuntimeException("User not found"));

        String request = 
            "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
            "xmlns:us=\"http://example.com/users\">" +
            "<soapenv:Body>" +
            "<us:getUserRequest><us:id>999</us:id></us:getUserRequest>" +
            "</soapenv:Body></soapenv:Envelope>";

        // Act & Assert
        mockMvc.perform(post("/ws")
                .contentType("text/xml")
                .content(request))
                .andDo(print())
                .andExpect(status().isInternalServerError());
    }
}