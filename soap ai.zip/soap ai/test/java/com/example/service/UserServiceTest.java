package com.example.service;

import com.example.exception.UserNotFoundException;
import com.example.model.User;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cache.CacheManager;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class UserServiceTest {

    @Autowired
    private UserService userService;

    @Autowired
    private CacheManager cacheManager;

    @BeforeEach
    void setUp() {
        // Clear cache before each test
        cacheManager.getCache("users").clear();
    }

    @Test
    public void whenValidId_thenUserShouldBeFound() {
        // Arrange & Act
        User user = userService.getUserById(1);

        // Assert
        assertNotNull(user);
        assertEquals(1, user.getId());
        assertEquals("User 1", user.getName());
        assertEquals("user1@example.com", user.getEmail());
    }

    @Test
    public void whenInvalidId_thenThrowException() {
        // Arrange & Act & Assert
        assertThrows(RuntimeException.class, () -> {
            userService.getUserById(-1);
        });
    }

    @Test
    public void whenCalledTwice_thenShouldHitCache() {
        // First call - should hit the service
        User firstCall = userService.getUserById(1);
        
        // Second call - should hit the cache
        User secondCall = userService.getUserById(1);
        
        // Assert same object reference due to caching
        assertSame(firstCall, secondCall);
    }

    @Test
    public void whenUserNotFound_thenThrowUserNotFoundException() {
        assertThrows(RuntimeException.class, () -> {
            userService.getUserById(999);
        });
    }

    @Test
    public void whenValidUser_thenCorrectFields() {
        // Arrange & Act
        User user = userService.getUserById(1);

        // Assert
        assertAll("User fields validation",
            () -> assertEquals(1, user.getId()),
            () -> assertNotNull(user.getName()),
            () -> assertTrue(user.getEmail().contains("@")),
            () -> assertTrue(user.getEmail().endsWith("example.com"))
        );
    }
}